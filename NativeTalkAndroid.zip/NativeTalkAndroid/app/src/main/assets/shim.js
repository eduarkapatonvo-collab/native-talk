/* Native Talk · puente Android
   Conecta la interfaz web con el teléfono: voz (SpeechRecognizer), voces (TextToSpeech),
   la IA por internet (Gemini gratis o Claude), grabación de audio y guardado local. */
(function () {
  var N = window.NTNative;
  if (!N) return;
  window.NT_ANDROID = true;
  document.documentElement.classList.add('is-android');
  try { Object.defineProperty(window, 'speechSynthesis', { value: null, configurable: true }); } catch (e) {}

  var seq = 0, waits = {};
  function wait(id) { return new Promise(function (res, rej) { waits[id] = { res: res, rej: rej }; }); }
  function take(id) { var w = waits[id]; delete waits[id]; return w; }
  var dl = { p: null, f: null, s: null }, tl = { s: null }, recId = null;

  window.__nt = {
    askDone: function (id, ok, v) { var w = take(id); if (!w) return; if (ok) w.res({ text: v, truncated: false }); else w.rej({ code: v || 'error' }); },
    ttsDone: function (id, ok) { var w = take(id); if (tl.s) tl.s({ state: 'idle', reason: ok ? 'completed' : 'stopped' }); if (!w) return; if (ok) w.res(); else w.rej({ code: 'stopped' }); },
    dictPartial: function (t) { if (dl.p) dl.p({ text: t }); },
    dictFinal: function (t) { if (dl.f) dl.f({ text: t }); },
    dictState: function (s, r) { if (dl.s) dl.s({ state: s, reason: r || '' }); },
    recDone: function (id, b64) {
      var w = take(id); if (!w) return;
      if (!b64) { w.rej({ code: 'no_audio' }); return; }
      var bin = atob(b64), a = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i);
      w.res(new Blob([a], { type: 'audio/wav' }));
    }
  };

  /* IA por internet: Gemini (gratis) o Claude */
  var sample = function (input) {
    var prompt = typeof input === 'string' ? input : (input || []).map(function (m) { return m.content; }).join('\n\n');
    var id = 'a' + (++seq), p = wait(id);
    N.ask(id, prompt);
    return p;
  };
  sample.json = function (input, opts) {
    return sample(input, opts).then(function (r) {
      var t = r.text || '', a = t.indexOf('{'), b = t.lastIndexOf('}');
      if (a < 0 || b < a) throw { code: 'parse' };
      try { return JSON.parse(t.slice(a, b + 1)); } catch (e) { throw { code: 'parse' }; }
    });
  };
  sample.limits = function () { return Promise.resolve({ images: false }); };

  /* Reconocimiento de voz continuo */
  var dict = {
    start: function () { N.listen(true); return Promise.resolve(); },
    stop: function () { N.listen(false); return new Promise(function (r) { setTimeout(r, 150); }); },
    onPartial: function (cb) { dl.p = cb; },
    onFinal: function (cb) { dl.f = cb; },
    onState: function (cb) { dl.s = cb; }
  };

  /* Voces del teléfono */
  var tts = {
    speak: function (arg, opts) {
      opts = opts || {};
      var lines = Array.isArray(arg) ? arg : [{ text: String(arg), language: opts.language, rate: opts.rate }];
      lines = lines.map(function (l) {
        return { text: String(l.text || ''), lang: String(l.language || opts.language || 'en'), rate: +(l.rate || opts.rate || 1) };
      });
      var id = 't' + (++seq), p = wait(id);
      if (tl.s) tl.s({ state: 'speaking' });
      N.speak(id, JSON.stringify(lines));
      return p;
    },
    add: function (a) { return tts.speak(a); },
    stop: function () { N.stopSpeak(); },
    onState: function (cb) { tl.s = cb; },
    onLine: function () {}, onPosition: function () {}, setRate: function () {}, pause: function () {}, resume: function () {}
  };

  /* Guardado en el teléfono */
  var store = {
    collection: function (p) {
      return {
        doc: function (k) {
          var key = p + '/' + k;
          return {
            get: function () { var v = N.load(key); try { return Promise.resolve(v ? JSON.parse(v) : null); } catch (e) { return Promise.resolve(null); } },
            set: function (o) { N.save(key, JSON.stringify(o)); return Promise.resolve(); }
          };
        }
      };
    }
  };
  var user = { id: function () { return Promise.resolve('me'); } };

  /* Grabación para el laboratorio de entonación */
  window.NTRec = {
    start: function () { recId = 'r' + (++seq); return N.recStart(recId); },
    stop: function () { var id = recId; recId = null; if (!id) return Promise.reject({ code: 'no_audio' }); var p = wait(id); N.recStop(); return p; }
  };

  /* Pantalla encendida mientras manejas */
  try {
    Object.defineProperty(navigator, 'wakeLock', {
      configurable: true,
      value: { request: function () { N.keepAwake(true); return Promise.resolve({ release: function () { N.keepAwake(false); return Promise.resolve(); }, addEventListener: function () {} }); } }
    });
  } catch (e) {}

  window.NTKey = {
    has: function () { return !!N.hasKey(); },
    set: function (k) { N.setKey(k); },
    provider: function () { return N.getProvider(); },
    setProvider: function (p) { N.setProvider(p); },
    speed: function () { return N.getSpeed(); },
    setSpeed: function (s) { N.setSpeed(s); }
  };

  window.claude = {
    use: function (n) {
      return Promise.resolve(n === 'sample' ? sample : n === 'dictation' ? dict : n === 'tts' ? tts : n === 'db' ? store : n === 'user' ? user : null);
    }
  };
})();
