package com.nativetalk.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Native Talk para Android.
 * La interfaz vive en assets/index.html; esta actividad le da voz, oído e internet:
 *  - SpeechRecognizer en modo continuo (se reinicia solo después de cada frase)
 *  - TextToSpeech con voz de EE. UU. para inglés y de México para español
 *  - IA por internet: Gemini de Google (plan gratis) o Claude, con la clave que guardas en la app
 *  - Grabación WAV para el laboratorio de entonación
 */
public class MainActivity extends Activity {

    private static final String BASE_URL = "https://nativetalk.app/";
    private static final String CLAUDE_URL = "https://api.anthropic.com/v1/messages";
    private static final String GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models";
    private static final int REQ_MIC = 7;
    private static final int REQ_FILE = 8;
    private static final int SAMPLE_RATE = 16000;

    private WebView web;
    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newCachedThreadPool();

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final Map<String, Voice> voiceCache = new HashMap<>();

    private SpeechRecognizer recognizer;
    private boolean wantListen = false;
    private boolean listening = false;
    private boolean startAfterPermission = false;
    private final Runnable restartRun = this::startRecognizer;

    private ValueCallback<Uri[]> fileCallback;

    private AudioRecord audioRecord;
    private volatile boolean recording = false;
    private ByteArrayOutputStream recBuffer;
    private Thread recThread;
    private String recId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("nativetalk", MODE_PRIVATE);

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Bridge(), "NTNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (u != null && !u.toString().startsWith(BASE_URL)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) { }
                    return true;
                }
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent pick = params.createIntent();
                    Intent chooser = Intent.createChooser(pick, "Elige o graba un audio");
                    Intent recordSound = new Intent(MediaStore_RECORD_SOUND_ACTION);
                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{recordSound});
                    startActivityForResult(chooser, REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });

        String html = readAsset("index.html");
        String shim = readAsset("shim.js");
        html = html.replace("<head>", "<head>\n<script>\n" + shim + "\n</script>");
        web.loadDataWithBaseURL(BASE_URL, html, "text/html", "UTF-8", null);

        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (!ttsReady) return;
            tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { }
                @Override public void onDone(String id) { finished(id, true); }
                @Override public void onError(String id) { finished(id, false); }
                @Override public void onError(String id, int code) { finished(id, false); }
                @Override public void onStop(String id, boolean interrupted) { finished(id, false); }
            });
        });
    }

    private static final String MediaStore_RECORD_SOUND_ACTION = "android.provider.MediaStore.RECORD_SOUND";

    private void finished(String utteranceId, boolean ok) {
        if (utteranceId != null && utteranceId.startsWith("end:")) {
            js("window.__nt&&__nt.ttsDone(" + JSONObject.quote(utteranceId.substring(4)) + "," + ok + ")");
        }
    }

    // ---------- JavaScript bridge ----------

    private class Bridge {
        @JavascriptInterface public boolean hasKey() { return !prefs.getString("key_" + provider(), "").isEmpty(); }
        @JavascriptInterface public void setKey(String k) { prefs.edit().putString("key_" + provider(), k == null ? "" : k.trim()).apply(); }
        @JavascriptInterface public String getProvider() { return provider(); }
        @JavascriptInterface public void setProvider(String p) { prefs.edit().putString("provider", "claude".equals(p) ? "claude" : "gemini").apply(); }
        @JavascriptInterface public String getSpeed() { return prefs.getString("speed", "quality"); }
        @JavascriptInterface public void setSpeed(String v) { prefs.edit().putString("speed", "fast".equals(v) ? "fast" : "quality").apply(); }
        @JavascriptInterface public String load(String k) { return prefs.getString("db:" + k, null); }
        @JavascriptInterface public void save(String k, String v) { prefs.edit().putString("db:" + k, v).apply(); }

        @JavascriptInterface public void ask(final String id, final String prompt) {
            io.execute(() -> {
                try {
                    String text = "claude".equals(provider()) ? callClaude(prompt) : callGemini(prompt);
                    js("__nt.askDone(" + JSONObject.quote(id) + ",true," + JSONObject.quote(text) + ")");
                } catch (UnknownHostException | SocketTimeoutException e) {
                    js("__nt.askDone(" + JSONObject.quote(id) + ",false,'network')");
                } catch (Exception e) {
                    String code = e.getMessage() == null ? "error" : e.getMessage();
                    js("__nt.askDone(" + JSONObject.quote(id) + ",false," + JSONObject.quote(code) + ")");
                }
            });
        }

        @JavascriptInterface public void speak(final String id, final String linesJson) {
            ui.post(() -> speakLines(id, linesJson));
        }

        @JavascriptInterface public void stopSpeak() {
            ui.post(() -> { if (tts != null) tts.stop(); });
        }

        @JavascriptInterface public void listen(final boolean on) {
            ui.post(() -> {
                if (on) {
                    wantListen = true;
                    startRecognizer();
                } else {
                    wantListen = false;
                    stopRecognizer();
                    jsState("idle", "stopped");
                }
            });
        }

        @JavascriptInterface public void keepAwake(final boolean on) {
            ui.post(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface public boolean recStart(final String id) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ui.post(() -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC));
                return false;
            }
            ui.post(() -> startRecording(id));
            return true;
        }

        @JavascriptInterface public void recStop() {
            io.execute(MainActivity.this::stopRecording);
        }
    }

    // ---------- IA por internet ----------

    private String provider() { return prefs.getString("provider", "gemini"); }
    private boolean fast() { return "fast".equals(prefs.getString("speed", "quality")); }

    /** Gemini de Google: plan gratis con límites diarios. Usa los alias "-latest" para no depender de nombres que cambian. */
    private String callGemini(String prompt) throws Exception {
        String key = prefs.getString("key_gemini", "").trim();
        if (key.isEmpty()) throw new IOException("no_key");
        String slot = fast() ? "fast" : "quality";
        String model = prefs.getString("gmodel_" + slot, fast() ? "gemini-flash-lite-latest" : "gemini-flash-latest");
        try {
            return geminiRequest(model, key, prompt, true);
        } catch (IOException e) {
            if (!"model_missing".equals(e.getMessage())) throw e;
            String alt = pickGeminiModel(key, fast());
            if (alt == null || alt.equals(model)) throw new IOException("http_404");
            prefs.edit().putString("gmodel_" + slot, alt).apply();
            return geminiRequest(alt, key, prompt, true);
        }
    }

    private String geminiRequest(String model, String key, String prompt, boolean rich) throws Exception {
        JSONObject body = new JSONObject();
        JSONArray parts = new JSONArray();
        parts.put(new JSONObject().put("text", prompt));
        JSONArray contents = new JSONArray();
        contents.put(new JSONObject().put("role", "user").put("parts", parts));
        body.put("contents", contents);
        if (rich) {
            JSONObject gc = new JSONObject();
            gc.put("responseMimeType", "application/json");
            if (!model.contains("lite")) gc.put("thinkingConfig", new JSONObject().put("thinkingLevel", "low"));
            body.put("generationConfig", gc);
        }
        HttpURLConnection c = (HttpURLConnection) new URL(GEMINI_URL + "/" + model + ":generateContent").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setDoOutput(true);
        c.setRequestProperty("content-type", "application/json");
        c.setRequestProperty("x-goog-api-key", key);
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String resp = in == null ? "" : readAll(in);
        c.disconnect();
        if (code == 400) {
            if (resp.contains("API_KEY_INVALID") || resp.contains("API key not valid")) throw new IOException("bad_key");
            if (rich) return geminiRequest(model, key, prompt, false);
            throw new IOException("http_400");
        }
        if (code == 401 || code == 403) throw new IOException("bad_key");
        if (code == 404) throw new IOException("model_missing");
        if (code == 429) throw new IOException("quota");
        if (code >= 400) throw new IOException("http_" + code);

        JSONArray cands = new JSONObject(resp).optJSONArray("candidates");
        if (cands == null || cands.length() == 0) throw new IOException("parse");
        JSONObject content = cands.getJSONObject(0).optJSONObject("content");
        JSONArray ps = content == null ? null : content.optJSONArray("parts");
        StringBuilder sb = new StringBuilder();
        if (ps != null) {
            for (int i = 0; i < ps.length(); i++) {
                JSONObject part = ps.getJSONObject(i);
                if (!part.optBoolean("thought", false)) sb.append(part.optString("text"));
            }
        }
        if (sb.length() == 0) throw new IOException("parse");
        return sb.toString();
    }

    /** Si un alias deja de existir, elige el modelo Flash más nuevo que la clave pueda usar. */
    private String pickGeminiModel(String key, boolean lite) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(GEMINI_URL + "?pageSize=1000").openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestProperty("x-goog-api-key", key);
            if (c.getResponseCode() != 200) return null;
            JSONArray models = new JSONObject(readAll(c.getInputStream())).optJSONArray("models");
            c.disconnect();
            if (models == null) return null;
            String best = null;
            int bestRank = -1;
            for (int i = 0; i < models.length(); i++) {
                JSONObject m = models.getJSONObject(i);
                String name = m.optString("name").replace("models/", "");
                String n = name.toLowerCase(Locale.ROOT);
                JSONArray methods = m.optJSONArray("supportedGenerationMethods");
                if (methods == null || !methods.toString().contains("generateContent")) continue;
                if (!n.contains("flash")) continue;
                if (n.contains("image") || n.contains("tts") || n.contains("audio") || n.contains("live") || n.contains("embed")) continue;
                int rank = 0;
                if (n.contains("lite") == lite) rank += 4;
                if (!n.contains("preview") && !n.contains("exp")) rank += 2;
                if (n.endsWith("-latest")) rank += 1;
                if (rank > bestRank || (rank == bestRank && best != null && name.compareTo(best) > 0)) { bestRank = rank; best = name; }
            }
            return best;
        } catch (Exception e) {
            return null;
        }
    }

    /** Claude: de pago por uso. */
    private String callClaude(String prompt) throws Exception {
        String key = prefs.getString("key_claude", "");
        if (key.isEmpty()) throw new IOException("no_key");
        JSONObject body = new JSONObject();
        body.put("model", fast() ? "claude-haiku-5-5" : "claude-sonnet-5-5");
        body.put("max_tokens", 1500);
        JSONArray messages = new JSONArray();
        JSONObject msg = new JSONObject();
        msg.put("role", "user");
        msg.put("content", prompt);
        messages.put(msg);
        body.put("messages", messages);

        HttpURLConnection c = (HttpURLConnection) new URL(CLAUDE_URL).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setDoOutput(true);
        c.setRequestProperty("content-type", "application/json");
        c.setRequestProperty("x-api-key", key);
        c.setRequestProperty("anthropic-version", "2023-06-01");
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String resp = in == null ? "" : readAll(in);
        c.disconnect();
        if (code == 401 || code == 403) throw new IOException("bad_key");
        if (code == 429 || code == 529) throw new IOException("rate_limited");
        if (code >= 400) throw new IOException("http_" + code);

        JSONArray content = new JSONObject(resp).getJSONArray("content");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < content.length(); i++) {
            JSONObject part = content.getJSONObject(i);
            if ("text".equals(part.optString("type"))) sb.append(part.optString("text"));
        }
        return sb.toString();
    }

    // ---------- Text to speech ----------

    private void speakLines(String id, String linesJson) {
        if (!ttsReady || tts == null) { finished("end:" + id, false); return; }
        try {
            JSONArray lines = new JSONArray(linesJson);
            ArrayList<JSONObject> list = new ArrayList<>();
            for (int i = 0; i < lines.length(); i++) {
                JSONObject l = lines.getJSONObject(i);
                if (!l.optString("text").trim().isEmpty()) list.add(l);
            }
            if (list.isEmpty()) { finished("end:" + id, true); return; }
            for (int i = 0; i < list.size(); i++) {
                JSONObject l = list.get(i);
                Locale loc = l.optString("lang", "en").startsWith("es") ? new Locale("es", "MX") : Locale.US;
                Voice v = bestVoice(loc);
                if (v != null) tts.setVoice(v); else tts.setLanguage(loc);
                tts.setSpeechRate((float) Math.max(0.5, Math.min(2.0, l.optDouble("rate", 1.0))));
                String uid = (i == list.size() - 1) ? "end:" + id : "part:" + id + ":" + i;
                tts.speak(l.optString("text"), i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, uid);
            }
        } catch (Exception e) {
            finished("end:" + id, false);
        }
    }

    private Voice bestVoice(Locale want) {
        String k = want.toString();
        if (voiceCache.containsKey(k)) return voiceCache.get(k);
        Voice best = null;
        int bestScore = Integer.MIN_VALUE;
        Set<Voice> voices = null;
        try { voices = tts.getVoices(); } catch (Exception ignored) { }
        if (voices != null) {
            for (Voice v : voices) {
                Locale l = v.getLocale();
                if (l == null || !l.getLanguage().equals(want.getLanguage())) continue;
                Set<String> f = v.getFeatures();
                if (f != null && f.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue;
                int score = v.getQuality();
                if (want.getCountry().equals(l.getCountry())) score += 1000;
                else if ("es".equals(want.getLanguage()) && "US".equals(l.getCountry())) score += 500;
                score -= v.getLatency() / 10;
                if (score > bestScore) { bestScore = score; best = v; }
            }
        }
        voiceCache.put(k, best);
        return best;
    }

    // ---------- Continuous speech recognition ----------

    private void startRecognizer() {
        if (!wantListen) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startAfterPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            wantListen = false;
            jsState("idle", "unavailable");
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(listener);
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L);
        try {
            recognizer.startListening(i);
            if (!listening) { listening = true; jsState("listening", ""); }
        } catch (Exception e) {
            restartLater(800);
        }
    }

    private void stopRecognizer() {
        ui.removeCallbacks(restartRun);
        if (recognizer != null) { try { recognizer.cancel(); } catch (Exception ignored) { } }
        listening = false;
    }

    private void restartLater(long ms) {
        ui.removeCallbacks(restartRun);
        if (wantListen) ui.postDelayed(restartRun, ms);
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle b) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float v) { }
        @Override public void onBufferReceived(byte[] bytes) { }
        @Override public void onEndOfSpeech() { }
        @Override public void onEvent(int t, Bundle b) { }

        @Override public void onPartialResults(Bundle b) {
            String t = firstResult(b);
            if (t != null && !t.isEmpty()) js("__nt.dictPartial(" + JSONObject.quote(t) + ")");
        }

        @Override public void onResults(Bundle b) {
            String t = firstResult(b);
            if (t != null && !t.isEmpty()) js("__nt.dictFinal(" + JSONObject.quote(t) + ")");
            restartLater(120);
        }

        @Override public void onError(int error) {
            if (!wantListen) return;
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                wantListen = false; listening = false;
                jsState("idle", "not_granted");
                return;
            }
            long delay = 150;
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
                try { recognizer.cancel(); } catch (Exception ignored) { }
                delay = 500;
            } else if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT || error == SpeechRecognizer.ERROR_SERVER) {
                delay = 1500;
            }
            restartLater(delay);
        }
    };

    private static String firstResult(Bundle b) {
        if (b == null) return null;
        ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return (r == null || r.isEmpty()) ? null : r.get(0);
    }

    private void jsState(String state, String reason) {
        js("__nt.dictState(" + JSONObject.quote(state) + "," + JSONObject.quote(reason) + ")");
    }

    // ---------- Recording for the intonation lab ----------

    private void startRecording(String id) {
        if (recording) return;
        boolean resume = wantListen;
        stopRecognizer();
        wantListen = resume;
        int min = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        try {
            audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, SAMPLE_RATE * 2));
            audioRecord.startRecording();
        } catch (Exception e) {
            js("__nt.recDone(" + JSONObject.quote(id) + ",'')");
            return;
        }
        recId = id;
        recBuffer = new ByteArrayOutputStream();
        recording = true;
        recThread = new Thread(() -> {
            byte[] buf = new byte[4096];
            while (recording) {
                int n = audioRecord.read(buf, 0, buf.length);
                if (n > 0 && recBuffer.size() < SAMPLE_RATE * 2 * 20) recBuffer.write(buf, 0, n);
            }
        });
        recThread.start();
    }

    private void stopRecording() {
        if (!recording) return;
        recording = false;
        try { recThread.join(1000); } catch (InterruptedException ignored) { }
        try { audioRecord.stop(); } catch (Exception ignored) { }
        audioRecord.release();
        audioRecord = null;
        byte[] pcm = recBuffer.toByteArray();
        String b64 = pcm.length < 3200 ? "" : Base64.encodeToString(wav(pcm), Base64.NO_WRAP);
        js("__nt.recDone(" + JSONObject.quote(recId) + "," + JSONObject.quote(b64) + ")");
        if (wantListen) ui.post(this::startRecognizer);
    }

    private static byte[] wav(byte[] pcm) {
        int byteRate = SAMPLE_RATE * 2;
        ByteArrayOutputStream o = new ByteArrayOutputStream(pcm.length + 44);
        writeStr(o, "RIFF"); writeInt(o, 36 + pcm.length); writeStr(o, "WAVE");
        writeStr(o, "fmt "); writeInt(o, 16); writeShort(o, 1); writeShort(o, 1);
        writeInt(o, SAMPLE_RATE); writeInt(o, byteRate); writeShort(o, 2); writeShort(o, 16);
        writeStr(o, "data"); writeInt(o, pcm.length);
        o.write(pcm, 0, pcm.length);
        return o.toByteArray();
    }
    private static void writeStr(ByteArrayOutputStream o, String s) { byte[] b = s.getBytes(StandardCharsets.US_ASCII); o.write(b, 0, b.length); }
    private static void writeInt(ByteArrayOutputStream o, int v) { o.write(v); o.write(v >> 8); o.write(v >> 16); o.write(v >> 24); }
    private static void writeShort(ByteArrayOutputStream o, int v) { o.write(v); o.write(v >> 8); }

    // ---------- Activity plumbing ----------

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_MIC) return;
        boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (granted && startAfterPermission) { startAfterPermission = false; startRecognizer(); }
        else if (!granted) { startAfterPermission = false; wantListen = false; jsState("idle", "not_granted"); }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            if (result == null && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        wantListen = false;
        stopRecognizer();
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        recording = false;
        io.shutdownNow();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private void js(final String code) {
        ui.post(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) { return readAll(in); }
        catch (IOException e) { return "<!DOCTYPE html><html><head></head><body>Error: " + name + "</body></html>"; }
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        return new String(o.toByteArray(), StandardCharsets.UTF_8);
    }
}
