# Native Talk para Android

App para aprender inglés de Estados Unidos hablando con Maya, una tutora que te corrige en voz alta. Está pensada para usarse manejando: todo es por voz.

- **Te entiende** con el reconocimiento de voz de tu Android (inglés de EE. UU.).
- **Te habla** con las voces de tu teléfono: inglés de EE. UU. y español de México.
- **Piensa y corrige** con Gemini de Google por internet, en su plan gratis. Claude queda como opción de pago.
- **Mide tu entonación** grabando tu voz en el laboratorio.

## Lo que necesitas

- Un Android 7 o más reciente, con internet.
- Una cuenta gratis de GitHub, para compilar la app en la nube.
- Una clave gratis de Gemini. Se crea en aistudio.google.com/apikey con tu cuenta de Google, sin tarjeta.

Todo es gratis: GitHub compila la app sin costo, el reconocimiento de voz y las voces son los de tu Android, y Gemini tiene un plan gratis con límites diarios.

## Paso 1. Compilar el APK en la nube

1. Entra a github.com y crea un repositorio nuevo llamado `native-talk`. Puede ser público: el código no lleva ninguna clave.
2. Sube todos los archivos de esta carpeta con **Add file → Upload files**.
3. Revisa que exista el archivo `.github/workflows/build.yml`. A veces no se sube al arrastrar la carpeta, porque es una carpeta oculta. Si no aparece, créalo con **Add file → Create new file**: escribe esa ruta como nombre y pega el contenido del archivo.
4. Abre la pestaña **Actions**. La compilación empieza sola y tarda unos 5 minutos. Si no empieza, abre "Compilar APK" y toca **Run workflow**.
5. Cuando termine, abre **Releases → Native Talk (última versión)** y verás el archivo `NativeTalk.apk`.

## Paso 2. Instalarla en tu teléfono

1. Desde tu Android, descarga `NativeTalk.apk` de la página de Releases.
2. Ábrelo. Android te pedirá permiso para instalar apps desde esa fuente (Chrome o Archivos): acéptalo e instala.
3. Si Play Protect avisa que la app es desconocida, elige instalar de todas formas: es tu propia app.

Si tienes computadora, también puedes instalarla con `adb install NativeTalk.apk`.

## Paso 3. Configurarla

1. En el teléfono, entra a aistudio.google.com/apikey con tu cuenta de Google y toca **Create API key**. Copia la clave.
2. Abre Native Talk y ve a **Cuaderno → Cerebro de Maya**. Deja **Servicio: Gemini (gratis)**, pega la clave y toca **Guardar**.
3. En **Modo** elige **Mejor calidad** o **Más rápida**. Si Maya tarda en contestar mientras manejas, usa **Más rápida**.
4. Permite el micrófono cuando la app lo pida.
5. Recomendado: en los ajustes del teléfono, busca "Texto a voz" y descarga las voces de alta calidad de inglés (Estados Unidos) y español (México).

## Cómo se usa manejando

1. Antes de arrancar: elige tu nivel y una situación en **Manos libres** y toca **Empezar**. Deja el teléfono en su soporte; la pantalla se queda encendida.
2. Maya te habla en inglés y suena un tono: es tu turno.
3. Contesta y di **"Okay Maya"** al terminar.
4. Si te equivocas, Maya te dice la corrección y te pide repetir. Si lo repites bien, sigue la plática.

Comandos: "Repeat" (repite), "Slower" (más lento), "In Spanish" (en español), "Start over" (borra), "New topic" (cambia de tema), "Help" (ayuda) y "Stop" (alto). Como el micrófono escucha en inglés, los comandos en inglés se entienden mejor.

Mientras Maya habla, la app apaga el micrófono para no escucharse a sí misma, y lo vuelve a encender cuando termina.

## Tu clave y tus datos

- La clave se guarda solo en tu teléfono y se envía únicamente al servicio que elegiste (Google o Anthropic).
- Tu progreso (errores, palabras, racha y nivel) se guarda en el teléfono.
- En el plan gratis de Gemini, Google puede usar lo que le envías para mejorar sus productos. Practica con frases normales y no digas datos personales.
- Si aparece "Llegaste al límite gratis", espera un minuto. Si sigue igual, el límite diario se renueva al día siguiente.
- La app usa los nombres "gemini-flash-latest" y "gemini-flash-lite-latest", que Google actualiza solo. Si alguno desaparece, la app busca sola el modelo Flash más nuevo disponible para tu clave.

## Para programadores

- `app/src/main/assets/index.html`: la interfaz completa (conversación, entonación, cuaderno y modo manos libres).
- `app/src/main/assets/shim.js`: el puente que conecta la interfaz con el teléfono.
- `app/src/main/java/com/nativetalk/app/MainActivity.java`: WebView con SpeechRecognizer continuo, TextToSpeech, llamadas a Gemini (o Claude) y grabación WAV.
- `.github/workflows/build.yml`: compila con Gradle 8.9 y Android Gradle Plugin 8.5.2, y publica el APK en Releases.

Sin dependencias externas: solo el SDK de Android (compileSdk 34, minSdk 24).
